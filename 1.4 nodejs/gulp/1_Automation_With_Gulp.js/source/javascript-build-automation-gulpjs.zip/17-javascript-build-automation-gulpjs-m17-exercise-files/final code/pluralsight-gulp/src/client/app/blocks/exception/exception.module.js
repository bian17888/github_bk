(function() {
    'use strict';

    angular.module('blocks.exception', ['blocks.logger']);
})();
