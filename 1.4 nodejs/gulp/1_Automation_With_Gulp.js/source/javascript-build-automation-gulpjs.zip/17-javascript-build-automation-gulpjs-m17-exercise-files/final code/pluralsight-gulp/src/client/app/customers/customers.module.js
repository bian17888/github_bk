(function() {
    'use strict';

    angular.module('app.customers', [
        'app.core',
        'app.widgets'
    ]);

})();
