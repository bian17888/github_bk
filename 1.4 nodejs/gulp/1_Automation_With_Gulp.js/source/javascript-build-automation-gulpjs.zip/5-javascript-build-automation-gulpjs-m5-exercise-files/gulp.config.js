module.exports = function() {
    var config = {

        // all js to vet
        alljs: [
            './src/**/*.js',
            './*.js'
        ]
    };

    return config;
};
