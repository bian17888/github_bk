var gulp = require('gulp');

gulp.task('hello-world', function(){
    console.log('Our first hello world gulp task!');
});
