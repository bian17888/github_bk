function *theGenerator(){
	yield "a return string";
};
var g = theGenerator(); // get an instance of the generator
console.log(g.next().value);