To run this examples:
- Go to this folder in Terminal
- Write “npm install” to install all the dependencies

Starting the programs
- “Write “node —harmony 1.js” (to start the first example)

