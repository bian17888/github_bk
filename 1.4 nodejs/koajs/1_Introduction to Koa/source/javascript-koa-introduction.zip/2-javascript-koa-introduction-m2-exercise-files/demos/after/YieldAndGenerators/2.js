function *differentStuff() {
	yield 21;
	yield { name: 'Marcus', age: 42, kids: ['Albert', 'Arvid', 'Gustav']};
	yield "A string with data in it";
};


var f = differentStuff();

console.log(f.next());
console.log(f.next());
console.log(f.next());
console.log(f.next());
console.log(f.next());
console.log(f.next());
console.log(f.next());
console.log(f.next());
console.log(f.next());
console.log(f.next());
console.log(f.next());
console.log(f.next());