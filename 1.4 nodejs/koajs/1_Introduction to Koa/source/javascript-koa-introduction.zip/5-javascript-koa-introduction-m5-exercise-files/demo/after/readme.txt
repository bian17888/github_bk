To run this examples:
- Go to this folder in Terminal
- Write “npm install” to install all the dependencies

You need MongoDb installed and running: http://www.mongodb.org/

Run test
- Write “npm test” in the terminal

Start the application
- Write “npm start” in the terminal
- Open a browser on http://localhost:3000
