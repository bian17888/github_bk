To run this examples:
- Go to this folder in Terminal
- Write “npm install” to install all the dependencies

Starting the programs
- “Write “node —harmony loggerdemo.js” (to start the first loggerdemo example)
- Go to http://localhost:3000 in most cases to try the application out
- In some cases a POST need to be done. Use a client for this, like PostMan (http://www.getpostman.com/)