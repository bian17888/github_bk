To run this examples:
- Go to this folder in Terminal
- Write “npm install” to install all the dependencies

You need MongoDb installed and running: http://www.mongodb.org/

Run test
- Write “npm test” in the terminal

Start the API
To run the API you will need a HTTP client. PostMan is a good choice (http://www.getpostman.com/)

- Write “npm start” in the terminal
- Create new users - POST to http://localhost:3000/user
- Get an user - GET to http://localhost:3000/user/[created id]
- Update an user - PUT to http://localhost:3000/user/[created id]
- Delete an user - DELETE to http://localhost:3000/user/[created id]
