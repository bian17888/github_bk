To run this examples:
- Go to this folder in Terminal
- Write “npm install” to install all the dependencies

Starting Hello Word
- “Write “node —harmony app.js”
- Open a browser at http://localhost:3000
(End the program with CTRL+C)

Starting User API:
- Make sure MongoDb installed (and started). See http://www.mongodb.org/ for information
- “Write “node —harmony app2.js”
- Open a HTTP client (http://www.getpostman.com/ for example)
- Post an object to http://localhost:3000/users to store it in MongoDb (localhost/koa_users)
- Get the user back out with the generated id http://localhost:3000/users/[your generated MongoDbId here]
- (End the program with CTRL+C)