> Examples for the Practical Node.js book [Apress, 2014]

# Practical Node.js

![](http://azatzbw4bszzsb.wpengine.netdna-cdn.com/wp-content/uploads/81AIpYkA46L-200.jpeg)

<http://practicalnodebook.com>

<http://amzn.to/NuQ0fM>

<http://www.apress.com/9781430265955>
